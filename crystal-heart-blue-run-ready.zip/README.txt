CRYSTAL HEART - BLUE VERSION

HOW TO RUN (IMPORTANT)
1. Extract this ZIP into a folder.
2. Open that folder in Visual Studio Code.
3. Install the "Live Server" extension if it is not already installed.
4. Right-click index.html and choose "Open with Live Server".
5. The project will open at a localhost address in your browser.

Do NOT open index.html by double-clicking it (file://). This project uses JavaScript ES Modules,
which should be served through a local web server.

Internet connection is required because Three.js, GSAP, the heart model, textures and music
are loaded from online CDNs/assets.

Files:
- index.html
- script.js
- style.css
